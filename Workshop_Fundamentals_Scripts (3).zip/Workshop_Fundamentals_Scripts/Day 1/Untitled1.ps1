﻿function Add-Extension
            {
                param ([string]$Name,[string]$Extension = "txt")
                $name = $name + "." + $extension
                $name

                
                            <#
            .SYNOPSIS
            Adds a file name extension to a supplied name.

            .DESCRIPTION
            Adds a file name extension to a supplied name.
            Takes any strings for the file name or extension.

            .PARAMETER Name
            Specifies the file name.

            .PARAMETER Extension
            Specifies the extension. "Txt" is the default.

            .INPUTS
            None. You cannot pipe objects to Add-Extension.

            .OUTPUTS
            System.String. Add-Extension returns a string with the extension or file name.

            .EXAMPLE
            C:\PS> extension -name "File"
            File.txt

            .EXAMPLE
            C:\PS> extension -name "File" -extension "doc"
            File.doc

            .EXAMPLE
            C:\PS> extension "File" "doc"
            File.doc

            .LINK
            http://www.fabrikam.com/extension.html

            .LINK
            Set-Item
            #>
            }
# SIG # Begin signature block
# MIIFbQYJKoZIhvcNAQcCoIIFXjCCBVoCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUQV4x3w7aGUy4DBH1j8tRBCV2
# 52egggMPMIIDCzCCAfOgAwIBAgIQSZDKKNO0j61FSArcnwBAzDANBgkqhkiG9w0B
# AQsFADATMREwDwYDVQQDDAh0ZXN0LmNvbTAeFw0xOTExMjAyMjA4NDZaFw0yMDEx
# MjAyMjI4NDZaMBMxETAPBgNVBAMMCHRlc3QuY29tMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEAqeZtFpiQDmz/e3Zz3sGX9km9iVqdlZtVaymrRq35cKGg
# KWXDzWY9HaHEPq6CJ1T4ojnxzeaXG2pt9lXr8gpvaX5Pcs/8Y2drPqZGPe34mjKq
# 8hFnqjhGBPbufT29Joft2VYoRkkYLqxWNlIqOkAGD3pO24hZZxEZA1mg34XAoVqt
# y8HKF2SwjM92FfsWkqx50dKaVLn5wocH+z9dOn3NyP8/nZTztMn6omR+TXsBJh6r
# vJMA5Katq44oKIGB0/xx7vnZlzhLyrYxZvyOQZvAs+A/pYXsTMQ8Nkoz8zoyB16r
# 0DFqy8DCi4csKkgGX4mKOSEQIiCKpyxKCcBUhgWD/QIDAQABo1swWTAOBgNVHQ8B
# Af8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwEwYDVR0RBAwwCoIIdGVzdC5j
# b20wHQYDVR0OBBYEFBZIiY5gXHd/Y/JHUhMz5IjTAw7gMA0GCSqGSIb3DQEBCwUA
# A4IBAQAp6S9pMSVmij8xHYjFjx/x8SkZR+hpbVhtcxjX9Cbjktlvsmqi7H7/iBXY
# Vu98q1IpkuCoMFAUq5OfyKBEkrMDvQo5Tf2jrdiGdEIbQsbuZs0rrSZGaOv/NMDi
# RrDHhb9IaICJ6VZ9Q8fbBOdNczunbxAt+1hNz+rYTPIfr1GDAr/Mt1AeJp5+55V3
# LH5aq71nb96zfbGtGS+bOIOL/PSvWqFlCHJtNxvgCi9+0XmuT5Ihc92UtyY6xYXE
# EGEWIJO9Kig5nI7B0ZkavKdkahYQ1+Uvihj2J0JiGaj2PWq4P7Dc4TnPwvyI/uyz
# Vq7HJScXnHlp4trFuLB4ZtGNFuNsMYIByDCCAcQCAQEwJzATMREwDwYDVQQDDAh0
# ZXN0LmNvbQIQSZDKKNO0j61FSArcnwBAzDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGC
# NwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUmDF6Mldz
# EhAU20VsPUePVsFqbjAwDQYJKoZIhvcNAQEBBQAEggEAgjUskRgUXmhI84aofQm4
# yJkZC0MwyTIs9mn1hyl1JjRHwuDSTFQBUUzF+um6ivRwjmr+GQ810ZWBBJIbVGbY
# jVEJ5I6MFiAwpiISYuIbTulj4GV8hev5H+nnPnpaOiNRaAGrsDOq10SCa8xsYTrO
# lCRIKlwPT9GzIskpxbqt+tFA0ys/Q45gIpd/sEaDrhantSaKbc55hYoK6njNszzz
# Xb6e/uHmL+Hg+dtN0a/0RIRDcGd5VvGZpLyNk70bzXhitOy5RtDeR6y3XjLS5W/a
# RkAamWxfoW93MSJE3Vjm06gnMeqeoqvI20aRInuhIQWnt281p3VBY8OQwWSRjJik
# Ew==
# SIG # End signature block
