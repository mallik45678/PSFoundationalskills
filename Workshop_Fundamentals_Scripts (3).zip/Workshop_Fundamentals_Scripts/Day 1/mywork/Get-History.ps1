﻿Get-History

Get-History -Count 1

Get-History | Where-Object {$_.CommandLine -like "*Service*"}

Get-History -Count 1

Get-History -ID 7 -Count 5 | Export-Csv History.csv

Get-History | Format-List -Property *