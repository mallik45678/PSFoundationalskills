﻿#requires -runsadministrator

get-service