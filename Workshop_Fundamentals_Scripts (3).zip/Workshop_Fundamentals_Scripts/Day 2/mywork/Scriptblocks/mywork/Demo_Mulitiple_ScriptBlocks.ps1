﻿ 
 Param(
 [String]$computername,
 [String]$logname

 )
 foreach($comp in $computername){
 
    
    Get-EventLog -ComputerName $comp -LogName $logname -Newest 10 | Format-List
      
    
    
 
 }

 
 
 Param($number) 
   foreach($n in $Number){
    Write-Host $n
 
 }