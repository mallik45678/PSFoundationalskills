﻿Get-Service -ComputerName localhost

#or

Param($computer)

get-service -ComputerName $computer